﻿# Project 3: From Portland to Portland
Project link: https://marishkins2.github.io/web_project_3/

### Overview
This is a website about jogging through different states. In this project I have learned a lot of new skills, but I got to apply the old ones as well.

Old Skills

BEM, display-flex, hover, etc.

New Skills
responsive web design, working with galleries

**Figma**

This is my first time using Figma, and it does get a little confusing as to what dimensions are actually applicable to the project. 
**Images**
I didn't like dowloading images one by one from figma, and I think it would save a lot of time if we could just download them in bulk. 

Overall, I have learned a lot, but there were also a lot of frustration along the way. 